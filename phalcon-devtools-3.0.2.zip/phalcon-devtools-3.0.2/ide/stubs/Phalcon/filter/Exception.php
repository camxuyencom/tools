<?php

namespace Phalcon\Filter;

/**
 * Phalcon\Filter\Exception
 * Exceptions thrown in Phalcon\Filter will use this class
 */
class Exception extends \Phalcon\Exception
{

}
