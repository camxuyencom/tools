<?php

namespace Phalcon\Queue\Beanstalk;

/**
 * Phalcon\Queue\Beanstalk\Exception
 * Exceptions thrown in Phalcon\Queue\Beanstalk will use this class
 */
class Exception extends \Phalcon\Exception
{

}
