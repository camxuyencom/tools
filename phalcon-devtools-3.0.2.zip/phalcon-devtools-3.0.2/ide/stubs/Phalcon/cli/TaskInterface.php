<?php

namespace Phalcon\Cli;

/**
 * Phalcon\Cli\TaskInterface
 * Interface for task handlers
 */
interface TaskInterface
{

}
