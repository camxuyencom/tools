<?php

namespace Phalcon\Application;

/**
 * Phalcon\Application\Exception
 * Exceptions thrown in Phalcon\Application class will use this class
 */
class Exception extends \Phalcon\Exception
{

}
