<?php

namespace Phalcon\Debug;

/**
 * Phalcon\Debug\Exception
 * Exceptions thrown in Phalcon\Debug will use this class
 */
class Exception extends \Phalcon\Exception
{

}
