<?php

namespace Phalcon\Paginator;

/**
 * Phalcon\Paginator\Exception
 * Exceptions thrown in Phalcon\Paginator will use this class
 */
class Exception extends \Phalcon\Exception
{

}
