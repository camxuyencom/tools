<?php

namespace Phalcon\Validation;

/**
 * Phalcon\Validation\CombinedFieldsValidator
 * This is a base class for combined fields validators
 */
abstract class CombinedFieldsValidator extends \Phalcon\Validation\Validator
{

}
