<?php

namespace Phalcon\Validation\Validator;

/**
 * Phalcon\Validation\Validator\Alnum
 * Check for alphanumeric character(s)
 * <code>
 * use Phalcon\Validation\Validator\Alnum as AlnumValidator;
 * $validator->add(
 * "username",
 * new AlnumValidator(
 * [
 * "message" => ":field must contain only alphanumeric characters",
 * ]
 * )
 * );
 * $validator->add(
 * [
 * "username",
 * "name",
 * ],
 * new AlnumValidator(
 * [
 * "message" => [
 * "username" => "username must contain only alphanumeric characters",
 * "name"     => "name must contain only alphanumeric characters",
 * ],
 * ]
 * )
 * );
 * </code>
 */
class Alnum extends \Phalcon\Validation\Validator
{

    /**
     * Executes the validation
     *
     * @param mixed $validation 
     * @param string $field 
     * @return bool 
     */
    public function validate(\Phalcon\Validation $validation, $field) {}

}
