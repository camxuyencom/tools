<?php

namespace Phalcon;

/**
 * Phalcon\Translate
 * Translate component allows the creation of multi-language applications using
 * different adapters for translation lists.
 */
abstract class Translate
{

}
