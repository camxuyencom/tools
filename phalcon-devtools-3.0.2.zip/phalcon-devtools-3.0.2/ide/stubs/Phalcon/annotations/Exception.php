<?php

namespace Phalcon\Annotations;


class Exception extends \Exception
{

}
