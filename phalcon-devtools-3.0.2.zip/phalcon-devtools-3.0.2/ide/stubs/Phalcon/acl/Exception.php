<?php

namespace Phalcon\Acl;

/**
 * Phalcon\Acl\Exception
 * Class for exceptions thrown by Phalcon\Acl
 */
class Exception extends \Phalcon\Exception
{

}
