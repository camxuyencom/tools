<?php

namespace Phalcon\Db;

/**
 * Phalcon\Db\Exception
 * Exceptions thrown in Phalcon\Db will use this class
 */
class Exception extends \Phalcon\Exception
{

}
