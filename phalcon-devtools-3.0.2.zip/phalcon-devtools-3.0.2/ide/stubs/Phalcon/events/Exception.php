<?php

namespace Phalcon\Events;

/**
 * Phalcon\Events\Exception
 * Exceptions thrown in Phalcon\Events will use this class
 */
class Exception extends \Phalcon\Exception
{

}
