<?php

namespace Phalcon\Loader;

/**
 * Phalcon\Loader\Exception
 * Exceptions thrown in Phalcon\Loader will use this class
 */
class Exception extends \Phalcon\Exception
{

}
