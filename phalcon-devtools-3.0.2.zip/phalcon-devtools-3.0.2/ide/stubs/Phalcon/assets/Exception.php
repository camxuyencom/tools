<?php

namespace Phalcon\Assets;

/**
 * Phalcon\Assets\Exception
 * Exceptions thrown in Phalcon\Assets will use this class
 */
class Exception extends \Phalcon\Exception
{

}
