<?php

namespace Phalcon\Mvc\Model\Validator;

/**
 * Phalcon\Mvc\Model\Validator\Email
 * Allows to validate if email fields has correct values
 * This validator is only for use with Phalcon\Mvc\Collection. If you are using
 * Phalcon\Mvc\Model, please use the validators provided by Phalcon\Validation.
 * <code>
 * use Phalcon\Mvc\Model\Validator\Email as EmailValidator;
 * class Subscriptors extends \Phalcon\Mvc\Collection
 * {
 * public function validation()
 * {
 * $this->validate(
 * new EmailValidator(
 * [
 * "field" => "electronic_mail",
 * ]
 * )
 * );
 * if ($this->validationHasFailed() === true) {
 * return false;
 * }
 * }
 * }
 * </code>
 */
class Email extends \Phalcon\Mvc\Model\Validator
{

    /**
     * Executes the validator
     *
     * @param mixed $record 
     * @return bool 
     */
    public function validate(\Phalcon\Mvc\EntityInterface $record) {}

}
