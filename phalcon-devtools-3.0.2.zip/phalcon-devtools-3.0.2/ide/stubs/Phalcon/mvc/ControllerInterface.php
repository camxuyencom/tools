<?php

namespace Phalcon\Mvc;

/**
 * Phalcon\Mvc\ControllerInterface
 * Interface for controller handlers
 */
interface ControllerInterface
{

}
