<?php

namespace Phalcon\Image;


class Exception extends \Phalcon\Exception
{

}
