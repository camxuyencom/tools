<?php

namespace Phalcon\Flash;

/**
 * Phalcon\Flash\Exception
 * Exceptions thrown in Phalcon\Flash will use this class
 */
class Exception extends \Phalcon\Exception
{

}
