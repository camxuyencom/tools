<?php

namespace Phalcon\Escaper;

/**
 * Phalcon\Escaper\Exception
 * Exceptions thrown in Phalcon\Escaper will use this class
 */
class Exception extends \Phalcon\Exception
{

}
